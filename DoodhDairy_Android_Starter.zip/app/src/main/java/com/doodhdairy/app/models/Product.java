package com.doodhdairy.app.models;
public class Product {
    public String id, name, description, unit, imageUrl, sellerId, sellerPhone;
    public double price, availableQty, deliveryCharge;
    public boolean active;
    public Product() {}
}
