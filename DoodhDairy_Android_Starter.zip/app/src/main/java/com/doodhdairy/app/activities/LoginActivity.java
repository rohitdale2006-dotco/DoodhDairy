package com.doodhdairy.app.activities;
import android.os.Bundle; import android.view.View; import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseException; import com.google.firebase.auth.*; import com.google.firebase.firestore.FirebaseFirestore;
import java.util.concurrent.TimeUnit; import java.util.HashMap; import java.util.Map;
public class LoginActivity extends AppCompatActivity {
 EditText phone, otp; String verificationId; PhoneAuthProvider.ForceResendingToken resendToken;
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(com.doodhdairy.app.R.layout.activity_simple);
  ((TextView)findViewById(R.id.titleText)).setText("Phone OTP Login");
  ((TextView)findViewById(R.id.infoText)).setText("Enter phone with country code, e.g. +919876543210");
  phone=findViewById(R.id.inputOne);phone.setVisibility(View.VISIBLE);phone.setHint("+91XXXXXXXXXX");
  otp=findViewById(R.id.inputTwo);otp.setVisibility(View.VISIBLE);otp.setHint("OTP");
  Button send=findViewById(R.id.actionButton);send.setText("Send OTP");send.setOnClickListener(v->sendOtp());
  Button verify=findViewById(R.id.secondButton);verify.setVisibility(View.VISIBLE);verify.setText("Verify OTP");verify.setOnClickListener(v->verifyOtp());
 }
 void sendOtp(){String n=phone.getText().toString().trim();if(n.length()<10){phone.setError("Enter phone number with country code");return;}
  PhoneAuthOptions options=PhoneAuthOptions.newBuilder(FirebaseAuth.getInstance()).setPhoneNumber(n).setTimeout(60L,TimeUnit.SECONDS).setActivity(this).setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
   public void onVerificationCompleted(PhoneAuthCredential c){signIn(c);}
   public void onVerificationFailed(FirebaseException e){Toast.makeText(LoginActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}
   public void onCodeSent(String id,PhoneAuthProvider.ForceResendingToken token){verificationId=id;resendToken=token;Toast.makeText(LoginActivity.this,"OTP sent",Toast.LENGTH_SHORT).show();}
  }).build();PhoneAuthProvider.verifyPhoneNumber(options);
 }
 void verifyOtp(){if(verificationId==null){Toast.makeText(this,"Send OTP first",Toast.LENGTH_SHORT).show();return;}signIn(PhoneAuthProvider.getCredential(verificationId,otp.getText().toString().trim()));}
 void signIn(PhoneAuthCredential c){FirebaseAuth.getInstance().signInWithCredential(c).addOnSuccessListener(r->{String uid=FirebaseAuth.getInstance().getUid();FirebaseFirestore db=FirebaseFirestore.getInstance();db.collection("users").document(uid).get().addOnSuccessListener(s->{if(s.exists()){String role=s.getString("role");go(role);}else{String role="CUSTOMER";Map<String,Object> u=new HashMap<>();u.put("uid",uid);u.put("phone",FirebaseAuth.getInstance().getCurrentUser().getPhoneNumber());u.put("role",role);u.put("verified",false);u.put("commissionDue",0);db.collection("users").document(uid).set(u).addOnSuccessListener(x->go(role));}});}).addOnFailureListener(e->Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show());}
 void go(String role){Class<?> c="ADMIN".equals(role)?AdminHistoryActivity.class:"SELLER".equals(role)?SellerDashboardActivity.class:CustomerHomeActivity.class;startActivity(new android.content.Intent(this,c));finish();}
}
