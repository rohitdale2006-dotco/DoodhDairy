package com.doodhdairy.app.activities;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
public class SplashActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle b){super.onCreate(b);
  if(FirebaseAuth.getInstance().getCurrentUser()==null){startActivity(new Intent(this,LanguageActivity.class));finish();return;}
  String uid=FirebaseAuth.getInstance().getUid();
  FirebaseFirestore.getInstance().collection("users").document(uid).get().addOnSuccessListener(s->{
   String role=s.getString("role");
   Class<?> next="ADMIN".equals(role)?AdminHistoryActivity.class:"SELLER".equals(role)?SellerDashboardActivity.class:CustomerHomeActivity.class;
   startActivity(new Intent(this,next));finish();
  }).addOnFailureListener(e->{startActivity(new Intent(this,LoginActivity.class));finish();});
 }
}
