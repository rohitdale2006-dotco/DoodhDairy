package com.doodhdairy.app.activities;
import android.os.Bundle; import android.widget.*; import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth; import com.google.firebase.firestore.*;
public class SellerDashboardActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(com.doodhdairy.app.R.layout.activity_simple);
 ((TextView)findViewById(R.id.titleText)).setText("Seller Dashboard");
 ((TextView)findViewById(R.id.infoText)).setText("Loading sales and commission due...");
 findViewById(R.id.inputOne).setVisibility(android.view.View.GONE);findViewById(R.id.secondButton).setVisibility(android.view.View.GONE);
 findViewById(R.id.actionButton).setOnClickListener(v->load());load();}
 void load(){String uid=FirebaseAuth.getInstance().getUid();FirebaseFirestore db=FirebaseFirestore.getInstance();
 db.collection("users").document(uid).get().addOnSuccessListener(u->{double due=u.getDouble("commissionDue")==null?0:u.getDouble("commissionDue");db.collection("orders").whereEqualTo("sellerId",uid).get().addOnSuccessListener(q->{double sales=0;int pending=0;for(DocumentSnapshot d:q){Double a=d.getDouble("totalAmount");if(a!=null)sales+=a;if("PENDING".equals(d.getString("status")))pending++;}((TextView)findViewById(R.id.infoText)).setText("Total order value: ₹"+sales+"\nCommission due to admin: ₹"+due+"\nPending orders: "+pending);});});}
}
