package com.doodhdairy.app.utils;
import com.google.firebase.firestore.FirebaseFirestore;
public final class FirebaseRefs {
    private FirebaseRefs() {}
    public static FirebaseFirestore db() { return FirebaseFirestore.getInstance(); }
}
