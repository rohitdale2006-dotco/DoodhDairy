package com.doodhdairy.app.models;
public class User {
    public String uid, name, phone, role, language;
    public boolean verified;
    public double commissionDue;
    public User() {}
}
