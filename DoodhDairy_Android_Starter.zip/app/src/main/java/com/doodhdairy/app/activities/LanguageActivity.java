package com.doodhdairy.app.activities;
import android.content.Intent; import android.os.Bundle; import android.widget.Button; import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class LanguageActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(com.doodhdairy.app.R.layout.activity_simple);
  ((TextView)findViewById(R.id.titleText)).setText("Choose language / भाषा निवडा");
  ((TextView)findViewById(R.id.infoText)).setText("Choose English, मराठी or हिन्दी.");
  Button btn=findViewById(R.id.actionButton); btn.setText("English"); btn.setOnClickListener(v->go("en"));
  Button more=findViewById(R.id.secondButton); more.setVisibility(android.view.View.VISIBLE);more.setText("मराठी");
  more.setOnClickListener(v->go("mr"));
  findViewById(R.id.inputOne).setVisibility(android.view.View.GONE);
 }
 private void go(String lang){getSharedPreferences("settings",MODE_PRIVATE).edit().putString("language",lang).apply();startActivity(new Intent(this,LoginActivity.class));finish();}
}
