package com.doodhdairy.app.models;
import com.google.firebase.Timestamp;
public class AdminTransaction {
    public String id, sellerId, type, note, adminId;
    public double amount;
    public Timestamp timestamp;
    public AdminTransaction() {}
}
