package com.doodhdairy.app.activities;
import android.os.Bundle; import android.widget.*; import androidx.appcompat.app.AppCompatActivity; import com.google.firebase.firestore.*;
public class AdminHistoryActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(com.doodhdairy.app.R.layout.activity_simple);
 ((TextView)findViewById(R.id.titleText)).setText("Admin Transaction History");
 ((TextView)findViewById(R.id.infoText)).setText("Earnings and withdrawals / commission collection log");
 findViewById(R.id.inputOne).setVisibility(android.view.View.GONE);findViewById(R.id.secondButton).setVisibility(android.view.View.GONE);
 findViewById(R.id.actionButton).setText("Load transactions");findViewById(R.id.actionButton).setOnClickListener(v->load());load();}
 void load(){FirebaseFirestore.getInstance().collection("adminTransactions").orderBy("timestamp",Query.Direction.DESCENDING).limit(100).get().addOnSuccessListener(q->{StringBuilder s=new StringBuilder();double earnings=0,withdrawals=0;for(DocumentSnapshot d:q){String type=d.getString("type");Double a=d.getDouble("amount");double amt=a==null?0:a;if("WITHDRAWAL".equals(type))withdrawals+=amt;else earnings+=amt;s.append(type).append(" ₹").append(amt).append(" — ").append(d.getString("note")).append("\n");}((TextView)findViewById(R.id.infoText)).setText("Earnings: ₹"+earnings+" | Withdrawals: ₹"+withdrawals+"\n\n"+s);}).addOnFailureListener(e->Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show());}
}
