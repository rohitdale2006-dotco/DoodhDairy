package com.doodhdairy.app.activities;
import android.os.Bundle; import android.widget.*; import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.*;
public class CustomerHomeActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(com.doodhdairy.app.R.layout.activity_simple);
 ((TextView)findViewById(R.id.titleText)).setText("Doodh Dairy Marketplace");
 ((TextView)findViewById(R.id.infoText)).setText("Available products (active listings)");
 findViewById(R.id.inputOne).setVisibility(android.view.View.GONE);
 Button btn=findViewById(R.id.actionButton);btn.setText("Refresh products");btn.setOnClickListener(v->load());
 findViewById(R.id.secondButton).setVisibility(android.view.View.GONE);load();}
 void load(){FirebaseFirestore.getInstance().collection("products").whereEqualTo("active",true).get().addOnSuccessListener(q->{StringBuilder s=new StringBuilder();for(DocumentSnapshot d:q){s.append(d.getString("name")).append(" — ₹").append(d.get("price")).append(" / ").append(d.get("unit")).append("\nStock: ").append(d.get("availableQty")).append("\n\n");}((TextView)findViewById(R.id.infoText)).setText(s.length()==0?"No products listed yet":s.toString());}).addOnFailureListener(e->Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show());}
}
