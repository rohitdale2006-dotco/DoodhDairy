package com.doodhdairy.app.models;
import com.google.firebase.Timestamp;
public class Order {
    public String orderId, customerId, sellerId, productId, productName, status, deliveryType;
    public double quantity, itemTotal, deliveryCharge, totalAmount, commission;
    public Timestamp timestamp;
    public Order() {}
}
