# Doodh Dairy Android starter

Java + Firebase starter project with white/sky-blue theme, OTP authentication, role routing, product listing, seller dashboard, order transaction and admin transaction history.

## Before building
1. Create a Firebase project and register Android app ID `com.doodhdairy.app`.
2. Download `google-services.json` into `app/`.
3. Enable Phone Authentication and create Firestore + Storage.
4. Deploy `firestore.rules`.
5. Open this folder in Android Studio and sync Gradle.

## Important security and completeness notes
- First-time OTP sign-in creates a CUSTOMER account. Do not let clients select or assign ADMIN/Seller roles themselves. Promote sellers/admins through a trusted admin console or Cloud Function after verification.
- This is a compile-oriented starter, not a fully production-complete marketplace. Add product CRUD/edit screens, seller verification workflow, complaints UI, Hindi locale option, Storage image upload, order history, and server-side transaction validation before release.
- Firestore client rules above are a starting point; the order placement transaction updates stock and seller commission, so production should move commission/stock/order creation into a trusted Cloud Function. Client security rules cannot guarantee all fields/business invariants across related documents.
- For calls, this sample uses ACTION_DIAL so it does not need runtime CALL_PHONE permission. WhatsApp helper is available in ProductDetailActivity's `contact(true)` but no separate button is wired in the simple starter layout.
- Admin PIN must be validated server-side (e.g. callable Cloud Function); never store a plain six-digit PIN in the Android app or Firestore-readable client document.
